<?php

namespace App\Http\Controllers;

use App\Models\PatientCaptureModel;
use App\Models\PharmacyModel;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Constants\Constants;
use App\Models\HcfModel;
use App\Models\Response;
use App\Models\UserModel;
use App\Models\RewardModel;
use Carbon\Carbon;
use Session;

session_start();

class HcfController extends Controller
{
    public $hcfObj;

    public function __construct()
    {
        $this->hcfObj = new HcfModel();
    }

    public function GetListHcf()
    {
        $responseData = new Response;
        $listHcf = $this->hcfObj->GetListHcf();
        if (!empty($listHcf)) {
            $responseData->Data = $listHcf;
            $responseData->Status = Constants::RESPONSE_STATUS_SUCCESS;
        } else {
            $responseData->Status = Constants::RESPONSE_STATUS_ERROR;
            $responseData->Data = "";
            $responseData->Message = Constants::RESPONSE_STATUS_HCF_NOTFOUND;
        }
        return json_encode($responseData);
    }

    public function GetHcfDetails()
    {
        $user = $_SESSION[Constants::SESSION_KEY_USER];
        $responseData = new Response;
        $hcfDetails = $this->hcfObj->GetHcfDetails($user->health_care_facility_id);
        $userObj = new UserModel();
        $topUser = $userObj->GetTopUser($user->health_care_facility_id);
        if (!empty($hcfDetails)) {
            $hcfDetails->TopUser = $topUser;
            $responseData->Data = $hcfDetails;
            $responseData->Status = Constants::RESPONSE_STATUS_SUCCESS;
        } else {
            $responseData->Status = Constants::RESPONSE_STATUS_ERROR;
            $responseData->Data = "";
            $responseData->Message = Constants::RESPONSE_STATUS_HCF_NOTFOUND;
        }
        return json_encode($responseData);
    }

    public function GetListHcfLocation()
    {
        $responseData = new Response;
        $user = $_SESSION[Constants::SESSION_KEY_USER];
        $listHcfLocation = $this->hcfObj->GetListHcfLocation($user->health_care_facility_id);
        if (!empty($listHcfLocation)) {
            $responseData->Data = $listHcfLocation;
            $responseData->Status = Constants::RESPONSE_STATUS_SUCCESS;
        } else {
            $responseData->Status = Constants::RESPONSE_STATUS_ERROR;
            $responseData->Data = array();
            $responseData->Message = Constants::RESPONSE_STATUS_HCF_NOTFOUND;
        }
        return json_encode($responseData);
    }

    public function GetListLocationByHcfId(Request $request)
    {
        $responseData = new Response;
        $checkHcf = $this->hcfObj->GetHcfById($request->hcfId);
        if (empty($checkHcf)) {
            $responseData->Status = Constants::RESPONSE_STATUS_ERROR;
            $responseData->Message = Constants::RESPONSE_STATUS_HCF_NOTFOUND;
        } else {
            $listHcfLocation = $this->hcfObj->GetListHcfLocation($request->hcfId);
            if (!empty($listHcfLocation)) {
                $responseData->Data = $listHcfLocation;
                $responseData->Status = Constants::RESPONSE_STATUS_SUCCESS;
            } else {
                $responseData->Status = Constants::RESPONSE_STATUS_ERROR;
                $responseData->Data = array();
                $responseData->Message = Constants::RESPONSE_STATUS_HCF_NOTFOUND;
            }
        }
        return json_encode($responseData);
    }

    public function AddHcfLocation(Request $request)
    {
        $responseData = new Response;
        if (empty($request->address) || empty($request->phone) || empty($request->name) || empty($request->email) || empty($request->city) || empty($request->state) || empty($request->zip) || empty($request->image) || empty($request->latitude) || empty($request->longitude)) {
            $responseData->Status = Constants::RESPONSE_STATUS_ERROR;
            $responseData->Message = Constants::RESPONSE_MESSAGE_INVALID_INPUT;
        } else {
            $user = $_SESSION[Constants::SESSION_KEY_USER];
            $checkEmail = $this->hcfObj->CheckEmail(trim($request->input('email')));
            if (!empty($checkEmail)) {
                $responseData->Status = Constants::RESPONSE_STATUS_ERROR;
                $responseData->Message = Constants::RESPONSE_MESSAGE_EMAIL_EXISTED;
            } else {
                if ($request->hasFile('image')) {
                    $file = $request->file('image');
                    $image_name = time() . $file->getClientOriginalName();
                    $image_url = Constants::CLINIC_IMAGE_URL . $image_name;
                    $request->file('image')->move(public_path(Constants::CLINIC_UPLOAD_IMAGE), $image_name);
                } else {
                    $image_url = '';
                }
                if (empty($request->hcf_id)) {
                    $listRequest = array(
                        'address' => $request->input('address'),
                        'phone' => $request->input('phone'),
                        'name' => $request->input('name'),
                        'email' => $request->input('email'),
                        'city' => $request->input('city'),
                        'state' => $request->input('state'),
                        'zip' => $request->input('zip'),
                        'image_url' => $image_url,
                        'latitude' => $request->input('latitude'),
                        'longitude' => $request->input('longitude'),
                        'health_care_facility_id' => $user->health_care_facility_id,
                        'created_at' => Carbon::now(),
                        'updated_at' => Carbon::now()
                    );
                } else {
                    $listRequest = array(
                        'address' => $request->input('address'),
                        'phone' => $request->input('phone'),
                        'name' => $request->input('name'),
                        'email' => $request->input('email'),
                        'city' => $request->input('city'),
                        'state' => $request->input('state'),
                        'zip' => $request->input('zip'),
                        'image_url' => $image_url,
                        'latitude' => $request->input('latitude'),
                        'longitude' => $request->input('longitude'),
                        'health_care_facility_id' => $request->hcf_id,
                        'created_at' => Carbon::now(),
                        'updated_at' => Carbon::now()
                    );
                }
                $addHcfLocation = $this->hcfObj->AddHcfLocation($listRequest);
                if (!empty($addHcfLocation)) {
                    $responseData->Data = $addHcfLocation;
                    $responseData->Status = Constants::RESPONSE_STATUS_SUCCESS;
                } else {
                    $responseData->Status = Constants::RESPONSE_STATUS_ERROR;
                    $responseData->Data = "";
                }
            }
        }

        return json_encode($responseData);
    }


    public function EditHcfLocation(Request $request)
    {
        $responseData = new Response;
        $user = $_SESSION[Constants::SESSION_KEY_USER];
        if (empty($request->health_care_facility_id)) {
            $checkLocationId = $this->hcfObj->CheckHcfLocationId($request->id, $user->health_care_facility_id);
        } else {
            $checkLocationId = $this->hcfObj->CheckHcfLocationId($request->id, $request->health_care_facility_id);
        }
        if (empty($checkLocationId)) {
            $responseData->Status = Constants::RESPONSE_STATUS_ERROR;
            $responseData->Message = Constants::RESPONSE_MESSAGE_LOCATION_NOTFOUND;
        } else {
            $checkEmailUpdate = $this->hcfObj->CheckEmailUpdate(trim($request->email), $request->id);
            if (!empty($checkEmailUpdate)) {
                $responseData->Status = Constants::RESPONSE_STATUS_ERROR;
                $responseData->Message = Constants::RESPONSE_MESSAGE_EMAIL_EXISTED;
            } else {
                if ($request->hasFile('image')) {
                    $file = $request->file('image');
                    $image_name = time() . $file->getClientOriginalName();
                    $image_url = Constants::CLINIC_IMAGE_URL . $image_name;
                    $request->file('image')->move(public_path(Constants::CLINIC_UPLOAD_IMAGE), $image_name);
                    $listRequest = array(
                        'address' => $request->input('address'),
                        'phone' => $request->input('phone'),
                        'name' => $request->input('name'),
                        'email' => $request->input('email'),
                        'city' => $request->input('city'),
                        'state' => $request->input('state'),
                        'zip' => $request->input('zip'),
                        'image_url' => $image_url,
                        'latitude' => $request->input('latitude'),
                        'longitude' => $request->input('longitude'),
                        'updated_at' => Carbon::now()
                    );
                } else {
                    $listRequest = array(
                        'address' => $request->input('address'),
                        'phone' => $request->input('phone'),
                        'name' => $request->input('name'),
                        'email' => $request->input('email'),
                        'city' => $request->input('city'),
                        'state' => $request->input('state'),
                        'zip' => $request->input('zip'),
                        'latitude' => $request->input('latitude'),
                        'longitude' => $request->input('longitude'),
                        'updated_at' => Carbon::now()
                    );
                }
                $editHcfLocation = $this->hcfObj->UpdateHcfLocation($request->input('id'), $listRequest);
                if (!empty($editHcfLocation)) {
                    $responseData->Data = $editHcfLocation;
                    $responseData->Status = Constants::RESPONSE_STATUS_SUCCESS;
                } else {
                    $responseData->Status = Constants::RESPONSE_STATUS_ERROR;
                }
            }
        }
        return json_encode($responseData);
    }

    public function DeleteHcfLocation(Request $request)
    {
        $responseData = new Response;
        $user = $_SESSION[Constants::SESSION_KEY_USER];
        if ($user->role != Constants::USER) {
            $deleteHcfLocation = $this->hcfObj->DeleteHcfLocation($request->hcfId);
            if (!empty($deleteHcfLocation)) {
                $patientCaptureObj = new PatientCaptureModel();
                $deletPatientCapture = $patientCaptureObj->DeletePatientCaptureByLocationId($request->hcfId);
                $responseData->Data = $deleteHcfLocation;
                $responseData->Status = Constants::RESPONSE_STATUS_SUCCESS;
            } else {
                $responseData->Status = Constants::RESPONSE_STATUS_ERROR;
                $responseData->Data = "";
            }
        } else {
            $responseData->Status = Constants::RESPONSE_STATUS_ACCESS_IS_DENIED;
        }
        return json_encode($responseData);
    }

    public function AddHcf(Request $request)
    {
        $responseData = new Response;
        $userObj = new UserModel();
        $rewardObj = new RewardModel();
        if (empty($request->full_name) || empty($request->email) || empty($request->password) || empty($request->hospital_name) || empty($request->address) || empty($request->city) || empty($request->state) || empty($request->zip) || empty($request->phone) || empty($request->image)) {
            $responseData->Status = Constants::RESPONSE_STATUS_ERROR;
            $responseData->Message = Constants::RESPONSE_MESSAGE_INVALID_INPUT;
        } else {
            if ($request->hasFile('image')) {
                $file = $request->file('image');
                $image_name = time() . $file->getClientOriginalName();
                $image_url = Constants::HCF_IMAGE_URL . $image_name;
                $request->file('image')->move(public_path(Constants::HCF_UPLOAD_IMAGE), $image_name);
            } else {
                $image_url = '';
            }
            $introduction = "<p><strong>" . $request->hospital_name . " has partnered with local pharmacies through a federal program. This program is designed to:</strong></p> <ul> <li><u>help patients save money on medications</u></li> <li><u>support " . $request->hospital_name . "with savings</u></li> </ul>";
            $addHcf = $this->hcfObj->AddHcf($request->hospital_name, $image_url, $introduction);
            $listRequest = array(
                'encrypted_password' => md5($request->password),
                'full_name' => $request->full_name,
                'avatar' => Constants::DEFAULT_AVATAR,
                'background' => Constants::DEFAULT_BACKGROUND,
                'email' => $request->email,
                'health_care_facility_id' => $addHcf,
                'city' => $request->city,
                'address' => $request->address,
                'state' => $request->state,
                'zip' => $request->zip,
                'phone' => $request->phone,
                'role' => Constants::HOSPITAL_ADMIN,
                'created_at' => Carbon::now(),
                'total_patient' => 0,
                'total_point' => 0,
                'token' => Constants::DEFAULT_TOKEN,
            );
            $addUser = $userObj->AddUser($listRequest);
            $addUserAvatar = $rewardObj->AddUserReward($addUser, Constants::DEFAULT_AVATAR);
            $addUserBackground = $rewardObj->AddUserReward($addUser, Constants::DEFAULT_BACKGROUND);
            if (empty($addHcf) || empty($addUser) || empty($addUserAvatar) || empty($addUserBackground)) {
                $responseData->Status = Constants::RESPONSE_STATUS_ERROR;
            } else {
                $responseData->Status = Constants::RESPONSE_STATUS_SUCCESS;
            }
        }
        return json_encode($responseData);
    }

    public function UpdateHcf(Request $request)
    {
        $responseData = new Response;
        if (!isset($request->name)) {
            $responseData->Status = Constants::RESPONSE_STATUS_ERROR;
            $responseData->Message = Constants::RESPONSE_MESSAGE_INVALID_INPUT;
        } else {
            $user = $_SESSION[Constants::SESSION_KEY_USER];
            if (empty($request->name)) {
                $responseData->Status = Constants::RESPONSE_STATUS_ERROR;
                $responseData->Message = Constants::RESPONSE_MESSAGE_INVALID_INPUT;
            } else {
                if ($request->hasFile('image')) {
                    $file = $request->file('image');
                    $image_name = time() . $file->getClientOriginalName();
                    $image_url = Constants::HCF_IMAGE_URL . $image_name;
                    $request->file('image')->move(public_path(Constants::HCF_UPLOAD_IMAGE), $image_name);
                    $listRequest = array(
                        'name' => $request->name,
                        'image_url' => $image_url,
                        'updated_at' => Carbon::now()
                    );
                } else {
                    $listRequest = array(
                        'name' => $request->name,
                        'updated_at' => Carbon::now()
                    );
                }
                if (empty($id)) {
                    $updateHcf = $this->hcfObj->UpdateHcf($request->id, $listRequest);
                } else {
                    $updateHcf = $this->hcfObj->UpdateHcf($user->health_care_facility_id, $listRequest);
                }
                if (!empty($updateHcf)) {
                    $responseData->Status = Constants::RESPONSE_STATUS_SUCCESS;
                    $responseData->Data = $updateHcf;
                } else {
                    $responseData->Status = Constants::RESPONSE_STATUS_ERROR;
                }
            }
        }
        return json_encode($responseData);
    }

    public function UpdateHcfIntroduction(Request $request)
    {
        $user = $_SESSION[Constants::SESSION_KEY_USER];
        $responseData = new Response();
        $updateHcf = $this->hcfObj->UpdateHcfIntroduction($user->health_care_facility_id, $request->introduction);
        $responseData->Data = $updateHcf;
        $responseData->Status = Constants::RESPONSE_STATUS_SUCCESS;
        return json_encode($responseData);
    }

    public function DeleteHcf(Request $request)
    {
        $responseData = new Response();
        $checkHcf = $this->hcfObj->GetHcfById($request->hcfId);
        if (!empty($checkHcf)) {
            $deleteHcf = $this->hcfObj->DeleteHcf($request->hcfId);
            if (!empty($deleteHcf)) {
                $pharmacyObj = new PharmacyModel();
                $userObj = new UserModel();
                $deleteLocation = $pharmacyObj->DeletePharmacyByHcfId($request->hcfId);
                $deleteLocation = $this->hcfObj->DeleteHcfLocation($request->hcfId);
                $deleteUser = $userObj->DeleteUserByHcf($request->hcfId);
                $responseData->Status = Constants::RESPONSE_STATUS_SUCCESS;
                $responseData->Data = $deleteHcf;
            } else {
                $responseData->Status = Constants::RESPONSE_STATUS_ERROR;
            }
        } else {
            $responseData->Status = Constants::RESPONSE_STATUS_ERROR;
            $responseData->Message = Constants::RESPONSE_STATUS_HCF_NOTFOUND;
        }
        return json_encode($responseData);
    }

    public function UpdateDiscountCardInfo(Request $request)
    {
        $responseData = new Response();
        $user = $_SESSION[Constants::SESSION_KEY_USER];
        if (!isset($request->rxgrp) || !isset($request->input_code)) {
            $responseData->Status = Constants::RESPONSE_STATUS_ERROR;
            $responseData->Message = Constants::RESPONSE_MESSAGE_INVALID_INPUT;
        } else {
            if ($request->hasFile('image')) {
                $file = $request->file('image');
                $image_name = time() . $file->getClientOriginalName();
                $image_url = Constants::DIS_COUNT_CARD . $image_name;
                $request->file('image')->move(public_path(Constants::DIS_COUNT_CARD_URL), $image_name);
            } else {
                $image_url = '';
            }
            $updateInfo = $this->hcfObj->UpdateDiscountCardInfo($user->health_care_facility_id, $request->rxgrp, $request->input_code, $image_url);
            if (!empty($updateInfo)) {
                $responseData->Status = Constants::RESPONSE_STATUS_SUCCESS;
                $responseData->Data = $updateInfo;
            } else {
                $responseData->Status = Constants::RESPONSE_STATUS_ERROR;
            }
            return json_encode($responseData);
        }
    }
}
