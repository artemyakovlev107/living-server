<?php

namespace App\Models;

class Response
{
    var $Status;
	var $Data;
	var $Message;
}
