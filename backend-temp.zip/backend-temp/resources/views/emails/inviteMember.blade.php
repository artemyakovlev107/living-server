<p>
Hi {{$full_name}},
</p>

<p>
You have been invited to the {{$hospital}} Doc & I account.
</p>
<p>
You can now access this when you login to <a href="{{$url}}"><span>Doc & I</span></a> using our default password {{$password}}. Please change the password as soon as you get logged in.
</p>

<p>
This is an automated system message, do not reply.
</p>
<p>
DocAndI Notifications
</p>