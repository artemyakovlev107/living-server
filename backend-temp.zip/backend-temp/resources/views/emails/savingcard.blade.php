<p>
Hi there,
</p>
<p>
Thank you for using our services! For better support to our patients, we would like to send the card over to you. You can use this card to purchase needed medication.
</p>
<p>
From Doc & I team
</p>