<p>A new user signs up with these below information:</p>

<p>1. Name: {{$name}}</p>
<p>2. Email Address:{{$email}}</p>
<p>3. Message:{{$mess}}</p>
