<p>A new user signs up with these below information:</p>

<p>1. Name: <?php echo e($name); ?></p>
<p>2. Email Address:<?php echo e($email); ?></p>
<p>3. Message:<?php echo e($mess); ?></p>
