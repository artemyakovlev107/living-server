<?php if(!isset($name)): ?>
    This is the pharmarcy info you have chosen:
    Pharmacy name: <?php echo e($pharmacyName); ?>,
    Pharmacy address: <?php echo e($pharmacyAddress); ?>, <?php echo e($city); ?>

<?php else: ?>
    <p><b>Hi <?php echo e($name); ?>,</b></p>
    <p><b>Please find your Prescription Savings Card attached.</b></p>

   <p style="font-size: 13px;"><i>You are receiving this email because you have verbally consented to receiving this
            email and attached documents on <?php echo e($time); ?>.</i></p>
    <?php if(isset($pharmacyName)): ?>
        <p>This is the pharmarcy info you have chosen:<p>
        <p>Pharmacy name: <?php echo e($pharmacyName); ?>,</p>
        <p>Pharmacy address: <?php echo e($pharmacyAddress); ?>, <?php echo e($city); ?></p>
    <?php endif; ?>
<?php endif; ?>

--
<img src="<?php echo e($docaniLogoUrl); ?>" width="60" height="30">