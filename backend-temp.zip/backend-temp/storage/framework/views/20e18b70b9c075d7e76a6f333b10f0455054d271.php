<p><b>Hi <?php echo e($name); ?>,</b></p>
	<p><b>Please find your Prescription Savings Card attached.</b></p>

	<p style="font-size: 20"><i>You are receiving this email because you have verbally consented to receiving this email and attached documents on <?php echo e($time); ?>.</i></p>
--
<?php /*<p><b>Noah Berkson</b> | <span style="color: red">Doc & I</span></p>
<p>COO and Partner <span style="color:red">| Mobile: 319-321-3014</span></p>*/ ?>
<img src="<?php echo e($docaniLogoUrl); ?>" width="60" height="35">