<p>
Hi <?php echo e($full_name); ?>,
</p>

<p>
You have been invited to the <?php echo e($hospital); ?> Doc & I account.
</p>
<p>
You can now access this when you login to <a href="<?php echo e($url); ?>"><span>Doc & I</span></a> using our default password <?php echo e($password); ?>. Please change the password as soon as you get logged in.
</p>

<p>
This is an automated system message, do not reply.
</p>
<p>
DocAndI Notifications
</p>