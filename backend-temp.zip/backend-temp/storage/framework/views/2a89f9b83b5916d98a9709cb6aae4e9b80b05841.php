<p>A request was made to reset your password for Doc & I. If you did not request this, please ignore this email</p>

<p>Please click on the following link to reset your password: 
<a href="<?php echo e($url); ?>"><span><?php echo e($url); ?></span></a>
<p>

<p>
If you are still having issues logging in please contact us - <?php echo e($myEmail); ?>

</p>
